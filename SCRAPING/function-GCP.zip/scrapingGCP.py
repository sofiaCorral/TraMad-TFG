def scrapingGCP(): 
    import pandas as pd
    import requests
    from datetime import datetime, date, time, timedelta
    import calendar
    from bs4 import BeautifulSoup

    page1 = requests.get("https://informo.madrid.es/informo/tmadrid/pm.xml")

    soup1 = BeautifulSoup (page1.content, 'lxml')

    rows = soup1.find_all('pm')
    
    ahora = datetime.now()
    formato1 = "%H-%M"
    cadena1 = ahora.strftime(formato1)

    ahora = datetime.now()
    formato2 = "%Y-%m-%d"
    cadena2 = ahora.strftime(formato2)
    formato3 = "%Y-%m-%d %H:%M:%S"
    cadena3 = ahora.strftime(formato3)

    dfprueba = pd.DataFrame()
    
    for i in rows:
        table_idelem = i.find_all('idelem')
        dataIdelem = [j.text for j in table_idelem]

        table_descripcion = i.find_all('descripcion')
        if table_descripcion == []:
            dataDescripcion = ['']
        else:
            dataDescripcion = [j.text for j in table_descripcion]

        table_accesoAsociado = i.find_all('accesoasociado')
        if table_accesoAsociado == []:
            dataAccesoAsociado = ['']
        else:
            dataAccesoAsociado = [j.text for j in table_accesoAsociado]

        table_intensidad = i.find_all('intensidad')
        if table_intensidad == []:
            dataIntensidad = ['']
        else:
            dataIntensidad = [j.text for j in table_intensidad]

        table_ocupacion = i.find_all('ocupacion')
        if table_ocupacion == []:
            dataOcupacion = ['']
        else:
            dataOcupacion = [j.text for j in table_ocupacion]

        table_carga = i.find_all('carga')
        if table_carga == []:
            dataCarga = ['']
        else:
            dataCarga = [j.text for j in table_carga]

        table_nivelServicio = i.find_all('nivelservicio')
        if table_nivelServicio == []:
            dataNivelServicio = ['']
        else:
            dataNivelServicio = [j.text for j in table_nivelServicio]

        table_intensidadSat = i.find_all('intensidadsat')
        if table_intensidadSat == []:
            dataIntensidadSat = ['']
        else:
            dataIntensidadSat = [j.text for j in table_intensidadSat]

        table_error = i.find_all('error')
        if table_error == []:
            dataError = ['']
        else:
            dataError = [j.text for j in table_error]

        table_subarea = i.find_all('subarea')
        if table_subarea == []:
            dataSubarea = ['']
        else:
            dataSubarea = [j.text for j in table_subarea]

        table_st_x = i.find_all('st_x')
        if table_st_x == []:
            dataSt_x = ['']
        else:
            dataSt_x = [j.text for j in table_st_x]

        table_st_y = i.find_all('st_y')
        if table_st_y == []:
            dataSt_y = ['']
        else:
            dataSt_y = [j.text for j in table_st_y]

        table_velocidad = i.find_all('velocidad')
        if (table_velocidad == []) or (table_velocidad == ['-1']):
            dataVelocidad = ['0']
        else:
            dataVelocidad = [j.text for j in table_velocidad]

        if not table_descripcion:
            urbano = 'N'
        else:
            urbano = 'Y'
        
        dfprueba = dfprueba.append({'idelem':dataIdelem[0],
                                    'descripcion':dataDescripcion[0],
                                    'accesoAsociado':dataAccesoAsociado[0],
                                    'intensidad':dataIntensidad[0],
                                    'ocupacion':dataOcupacion[0],
                                    'carga':dataCarga[0],
                                    'nivelServicio':dataNivelServicio[0],
                                    'intensidadSat':dataIntensidadSat[0],
                                    'error':dataError[0], 'subarea':dataSubarea[0],
                                    'st_x':dataSt_x[0], 'st_y':dataSt_y[0],
                                    'velocidad': dataVelocidad[0],
                                    'Fecha_hora': cadena3,
                                    'Urbano': urbano}, ignore_index= True)
    
    direccion = 'gs://traffic-sofia-bucket/'+str(cadena2)+'/'+str(cadena1)+'.xlsx'
    dfprueba.to_excel(str(direccion), index = False)
    
    return(dfprueba)