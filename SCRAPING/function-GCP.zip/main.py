def main(data, context):
    import time
    import pandas as pd
    from datetime import datetime
    import scrapingGCP as sgcp

    # count = 0
    # while True:
    #     count = count + 1
    sgcp.scrapingGCP()
        # if count == 144:
        #     direccion = 'gs://traffic-sofia-bucket/'+str(cadena2)+'/'+str(formato1)+'.xlsx'
        #     #direccion = 'C:/Users/sofia/TFG/APP-TRAFICO-TFG-/SCRAPING/traffic-data/'+str(cadena2)+'.csv'
        #     #dfprueba = scrapingGCP(dfprueba)
        #     #dfprueba.to_csv(str(direccion), sep=';', index = False)
        #     dfprueba.to_excel(str(direccion), index = False)
        #     #print('stop')
        #     break
        # time.sleep(600)