import pandas as pd

def concatenar(data, context):
  df = pd.DataFrame()
  for j in range(0,13):
      if j < 10:
          hora = "0"+str(j)
      else:
          hora = str(j)
      for k in ['00','10','20','30','40','50']:
          direccion = 'gs://traffic-sofia-bucket/2022-05-15/' + hora + '-'+ k +'.xlsx'
            #print(direccion)
          dfIndividual = pd.read_excel(direccion)
          df = pd.concat([df, dfIndividual], axis = 0)
            #df = df.append(dfIndividual)
          print(j)
 
 
  # df = pd.read_excel('gs://traffic-sofia-bucket/2022-05-02/01-00.xlsx')
  print('pasado bucle for')
  print(len(df))
  direccionBucket = 'gs://traffic-sofia-bucket/Pruebas/Domingo-3.xlsx'
  df.to_excel(str(direccionBucket), index = False)
  print('Pasado to_excel')
  return 'Conseguido'