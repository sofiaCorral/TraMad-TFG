import pandas as pd

def concatenar(data, context):
  df = pd.DataFrame()
  for j in ['Lunes', 'Martes','Miercoles','Jueves','Viernes','Sabado','Domingo']:
    direccion = 'gs:///traffic-sofia-bucket/FicheroDiario/'+ j +'.csv'
    dfIndividual = pd.read_csv(direccion)
    df = pd.concat([df, dfIndividual], axis = 0)
    print(j)
 
  print('pasado bucle for')
  print(len(df))
  direccionBucket = 'gs://traffic-sofia-bucket/FicheroDiario/TrafficTotal.csv'
  df.to_csv(str(direccionBucket))
  print('Pasado to_csv')
  return 'Conseguido'