import pandas as pd

def concatenar(data, context):
  df = pd.DataFrame()
  for j in range(1,5):
          direccion = 'gs://traffic-sofia-bucket/Pruebas/Domingo-' + str(j) + '.xlsx'
            #print(direccion)
          dfIndividual = pd.read_excel(direccion)
          df = pd.concat([df, dfIndividual], axis = 0)
            #df = df.append(dfIndividual)
          print(j)
 
 
  # df = pd.read_excel('gs://traffic-sofia-bucket/2022-05-02/01-00.xlsx')
  print('pasado bucle for')
  print(len(df))
  direccionBucket = 'gs://traffic-sofia-bucket/FicheroDiario/Domingo.csv'
  df.to_csv(str(direccionBucket))
  print('Pasado to_excel')
  return 'Conseguido'